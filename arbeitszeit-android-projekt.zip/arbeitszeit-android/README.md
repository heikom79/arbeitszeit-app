# Meine Arbeitszeit – Android-Projekt

Android-WebView-App mit lokaler Speicherung und PDF-Druckdialog. Das PDF ist an das vom Nutzer bereitgestellte HMP Profi GmbH-Blanko angelehnt: Stammdaten, Monats-/Tageszeilen 1–31, Beginn/Ende, Arbeitszeit, Pause, Samstag/Sonntag, Nacht, Feiertag, Bemerkungen, Summen, Soll/Ist, AZ-Guthaben/Schuld und Unterschriftsfelder.

## APK bauen
Dieses Projekt benötigt Android SDK/Gradle. Ein GitHub-Actions-Workflow liegt unter `.github/workflows/build-apk.yml` und kann nach dem Einchecken der Projektdateien eine Debug-APK bauen.

Die App speichert Zeiten lokal im App-WebView. Deinstallieren oder App-Daten löschen kann lokale Daten entfernen. Nutze JSON-Sicherungen regelmäßig.

## Hinweise
- PDF-Export öffnet den Android-Druckdialog; dort „Als PDF speichern“ auswählen.
- Vor einer offiziellen Abgabe das erzeugte PDF und die betrieblichen Soll-/Überstundenregeln prüfen.
- Die Debug-APK ist nicht für eine Play-Store-Veröffentlichung signiert.
